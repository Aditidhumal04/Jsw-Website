package com.as.samples;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FormProcess
 */
@WebServlet("/FormProcess")
public class FormProcess extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	//String c="carpenter";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	

	
	
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	//String compno=request.getParameter("compno");
    	String dte=request.getParameter("dte");
		//String nme=request.getParameter("nme");
		String dept=request.getParameter("dept");
		String loc=request.getParameter("loc");
		//String noc=request.getParameter("noc");
		String complaint=request.getParameter("complaint");
		
		
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","root"); 
			if(con!= null ) {
				System.out.println("Connection Established");
				
				
				
				
				PreparedStatement stmt=con.prepareStatement( "UPDATE TESTI SET DEPT=? ,LOC=?, COMPLAINT=?, DTE=?, COMPLAINT_FOR=?  WHERE COMPLAINT_ID = (select max(COMPLAINT_ID) from testi)");  
				stmt.setString(1,dept);//1 specifies the first parameter in the query  
				
				stmt.setString(2,loc); 
				stmt.setString(3,complaint); 
				stmt.setString(4,dte);
				//stmt.setString(5,compno);
				stmt.setString(5,"carpenter");
				
				
				//stmt.setString(5,complaint); 
				//stmt.setString(6,empno); 
				
				
				  
				int i=stmt.executeUpdate();
				System.out.println(i);
				if(i==0) {
					
					String redirectURL = "form.jsp";
			        response.sendRedirect(redirectURL);
				
				}else {
					String redirectURL = "thanku.jsp";
			        response.sendRedirect(redirectURL);
				}
			}
			else {
				System.out.println("Connection not Established");
				String redirectURL = "form.jsp";
		        response.sendRedirect(redirectURL);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} 
		
		
		
		
		//System.out.println("complaint no is"+compno);
		//System.out.println("name is"+nme);
		System.out.println("department is"+dept);
		System.out.println("location is"+loc);
		//System.out.println("nature of complaint  is"+noc);
		System.out.println("complaint is"+complaint);
		System.out.println("date is"+dte);
		
		
		
		//request.getSession().setAttribute("complaint no", compno);
		//request.getSession().setAttribute("nme", nme);
		request.getSession().setAttribute("dept", dept);
		request.getSession().setAttribute("loc", loc);
		//request.getSession().setAttribute("noc", noc);
		request.getSession().setAttribute("complaint", complaint);
		request.getSession().setAttribute("date ", dte);
		
		
		//response.sendRedirect("displayfromdb.jsp");
		
	}
    
    
    
  
    
  

}

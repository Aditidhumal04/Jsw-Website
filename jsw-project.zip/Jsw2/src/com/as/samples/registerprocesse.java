package com.as.samples;



 
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/registerprocesse")
public class registerprocesse extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       int flag=0;
    
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String empno = request.getParameter("empno");
		String name = request.getParameter("name");
		//String username = request.getParameter("username");
		String pass = request.getParameter("pass");
		//String address = request.getParameter("address");
		String contact = request.getParameter("contact");
		String email = request.getParameter("email");
		//String t=("carpenter");
		
		/*if(first_name.isEmpty() || last_name.isEmpty() || username.isEmpty() || 
				pass.isEmpty() || address.isEmpty() || contact.isEmpty())
		{
			RequestDispatcher req = request.getRequestDispatcher("register.jsp");
			req.include(request, response);
		}
		else
		{
			//RequestDispatcher req = request.getRequestDispatcher("register_2.jsp");
			//req.forward(request, response);*/
			
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","root"); 
				if(con!= null) {
					System.out.println("Connection Established");
					
					String sql = "select * from testi";
					  Statement s = con.createStatement();
					  //s.executeQuery (sql);
					   ResultSet rs = s.executeQuery(sql);
					  
					   while (rs.next()){
						   String empNo=rs.getString(1);
						    if(empNo.equals(empno)){
						    	flag=1;
						        break;
						    }
						    
						    else {
						    flag=0;
						    }
						  
					   }
					
					   if(flag==1)
					    {
					    
					    	String redirectURL = "logine.jsp";
					        response.sendRedirect(redirectURL);
					    
					    }
					   else {
					PreparedStatement stmt=con.prepareStatement("INSERT INTO testi VALUES ( ?,?,?,?,?,?,default,default,default,default,default,default)");  
					stmt.setString(1,empno);//1 specifies the first parameter in the query  
					stmt.setString(2,name); 
					//stmt.setString(3,username); 
					stmt.setString(3,pass); 
					//stmt.setString(5,address); 
					stmt.setString(4,contact); 
					stmt.setString(5,email);
					//stmt.setString(10,t);
					stmt.setString(6,"electrician");  
					
					
					
					  
					int i=stmt.executeUpdate();
					System.out.println(i);
					
					String redirectURL = "logine.jsp";
			        response.sendRedirect(redirectURL);
				}
				}
				else {
					System.out.println("Connection not Established");
					String redirectURL = "logine.jsp";
			        response.sendRedirect(redirectURL);
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			} 
			
			
			request.getSession().setAttribute("empno", empno);
			request.getSession().setAttribute("name", name);
			//request.getSession().setAttribute("username", username);
			request.getSession().setAttribute("pass", pass);
			//request.getSession().setAttribute("address", address);
			request.getSession().setAttribute("contact", contact);
			request.getSession().setAttribute("email", email);
			
			
		}
	}
 
//}